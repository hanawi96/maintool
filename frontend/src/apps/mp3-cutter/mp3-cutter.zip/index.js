import MP3CutterMain from './components/MP3CutterMain';

export default MP3CutterMain;